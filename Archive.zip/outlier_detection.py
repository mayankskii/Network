from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import LocalOutlierFactor
from scipy import stats
from sklearn.ensemble import IsolationForest

class OutlierDetection():
    
    def __init__(self, df):
        """Generate descriptive statistics.

        Parameters
        ----------
        df : pd.DataFrame
            Dataframe for which outliers are calculated.

        Methods
        -------
        bool
            True if successful, False otherwise.

        """
        self.df = df
    
    def dbscan(self, two_columns, db=None):
        """Density based scan with noise. Alternatively used in clustering also.
        
        Parameters
        ----------
        two_columns : list
            Column names on which multivariate DBscan to be applied.
        db : DBSCAN object
            DBSCAN object init with specified params.

        Returns
        -------
        dict
            Metrics and dataframe denoting outliers.
        """
        if db is None:
            db = DBSCAN(min_samples=10, n_jobs=-1).fit(self.df[two_columns])
        else:
            pass
        core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
        core_samples_mask[db.core_sample_indices_] = True
        labels = db.labels_
        
        n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
        n_noise_ = list(labels).count(-1)
        
        result = {'labels': labels,
                'est_clusters': n_clusters_, 
                'est_noise_pts' : n_noise_, 
                'homogeneity' : metrics.homogeneity_score(labels_true, labels),
                'completeness' : metrics.completeness_score(labels_true, labels),
                'V_measure' : metrics.v_measure_score(labels_true, labels),
                'adj_rand' : metrics.adjusted_rand_score(labels_true, labels),
                'adj_mutual_info' : metrics.adjusted_mutual_info_score(labels_true, labels),
                'silehouette_coefficient' : metrics.silhouette_score(X, labels)}
        
        return result
    
    def local_outlier_factor(self, two_columns, lof=None):
        """Local Outlier Factor. Alternatively used in clustering also.
        
        Parameters
        ----------
        two_columns : list
            Column names on which multivariate LOF to be applied.

        Returns
        -------
        array
        
        """
        if lof is None:
            lof = LocalOutlierFactor(n_neighbors=2).fit_predict(self.df[two_columns])
        else:
            pass
        lof_label = lof.negative_outlier_factor_
        
        return lof_label
    
    def mad(self, one_columns):
        """Mean absolute deviation based outlier detection.
        
        Parameters
        ----------
        two_columns : list
            Column name on which univariate detection to be applied.

        Returns
        -------
        array
        
        """
        iqr =  np.quantile(X, 0.75, axis=0) - np.quantile(self.df[two_columns], 0.25, axis=0)
        # IQR may be zero. To avoid inf, fill with the variance
        iqr[np.where(iqr==0)] = np.var(self.df[two_columns], axis=0)[np.where(iqr==0)] 
        return np.median(np.abs(self.df[two_columns])/iqr, axis=1)
    
    def isolation_forest(self, two_columns, y):
        """Mean absolute deviation based outlier detection.
        
        Parameters
        ----------
        two_columns : list
            Column names on which bivariate isolation detection to be applied.
        y : array
            Array for which prediction to be generated.

        Returns
        -------
        dict
            Metrics and dataframe denoting outliers.
        """
        iso = IsolationForest(random_state=0).fit(self.df[two_columns])
        return iso.predict(y)