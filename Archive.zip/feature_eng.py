def feature_importance(model, data):
    """Function to show which features are most important in the model.

    Parameters
    ----------
    model : model object
        Dataframe for which statistics are calculated. Models with feature_importance methods can only be used.
    data: DataFrame
        Train dataframe.

    Returns
    -------
    DataFrame
        Columns with respective feature importances without scale.
    
    """
    fea_imp = pd.DataFrame({'imp': model.feature_importances_, 'col': data.columns})
    fea_imp = fea_imp.sort_values(['imp', 'col'], ascending=[True, False]).iloc[-30:]
    _ = fea_imp.plot(kind='barh', x='col', y='imp', figsize=(20, 10))
    return fea_impind='barh', x='col', y='imp', figsize=(20, 10))
    return fea_imp