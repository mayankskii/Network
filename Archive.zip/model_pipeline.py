# Import Dependencies
%matplotlib inline

# Start Python Imports
import math, time, random, datetime

# Data Manipulation
import numpy as np
import pandas as pd

# Visualization 
import matplotlib.pyplot as plt
import missingno
import seaborn as sns
plt.style.use('seaborn-whitegrid')

# Preprocessing
from sklearn.preprocessing import OneHotEncoder, LabelEncoder, label_binarize

# Machine learning
import catboost
from sklearn.model_selection import train_test_split
from sklearn import model_selection, tree, preprocessing, metrics, linear_model
from sklearn.svm import LinearSVC
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LinearRegression, LogisticRegression, SGDClassifier
from sklearn.tree import DecisionTreeClassifier
from catboost import CatBoostClassifier, Pool, cv

import warnings
warnings.filterwarnings('ignore')

def view(df):
    """Mean absolute deviation based outlier detection.

    Parameters
    ----------
    two_columns : list
        Column name on which univariate detection to be applied.

    Returns
    -------
    array

    """
    # Filling call to descriptive_summary... and split to train_test

    # Plot graphic of missing values
    missingno.matrix(train, figsize = (30,10))

def mad(self, one_columns):
    """Mean absolute deviation based outlier detection.

    Parameters
    ----------
    two_columns : list
        Column name on which univariate detection to be applied.

    Returns
    -------
    array

    """
X_train = selected_df.drop('Survived', axis=1) # data
y_train = selected_df.Survived # labels

def fit_ml_algo(algo, X_train, y_train, cv):
    """Function that runs the requested algorithm and returns the accuracy metrics.

    Parameters
    ----------
    algo : object
        algorithmn to be used with presets.
    X_train : pd.DataFrame
        train frame
    y_train : pd.DataFrame
        train labels
    cv : int, >0
        cross validation

    Returns
    -------
    prediction accuracy with cv

    """
    
    # One Pass
    model = algo.fit(X_train, y_train)
    acc = round(model.score(X_train, y_train) * 100, 2)
    
    # Cross Validation 
    train_pred = model_selection.cross_val_predict(algo, 
                                                  X_train, 
                                                  y_train, 
                                                  cv=cv, 
                                                  n_jobs = -1)
    # Cross-validation accuracy metric
    acc_cv = round(metrics.accuracy_score(y_train, train_pred) * 100, 2)
    
    return train_pred, acc, acc_cv

def run_algos():
    """Passing the preset algo to run function above.

    Returns
    -------
    pd.DataFrame
        run accuracy with and without cv.

    """
    # Logistic Regression
    start_time = time.time()
    train_pred_log, acc_log, acc_cv_log = fit_ml_algo(LogisticRegression(), 
                                                                   X_train, 
                                                                   y_train, 
                                                                        10)
    log_time = (time.time() - start_time)
    print("Accuracy: %s" % acc_log)
    print("Accuracy CV 10-Fold: %s" % acc_cv_log)
    print("Running Time: %s" % datetime.timedelta(seconds=log_time))

    # k-Nearest Neighbours
    start_time = time.time()
    train_pred_knn, acc_knn, acc_cv_knn = fit_ml_algo(KNeighborsClassifier(), 
                                                      X_train, 
                                                      y_train, 
                                                      10)
    knn_time = (time.time() - start_time)
    print("Accuracy: %s" % acc_knn)
    print("Accuracy CV 10-Fold: %s" % acc_cv_knn)
    print("Running Time: %s" % datetime.timedelta(seconds=knn_time))

    # Gaussian Naive Bayes
    start_time = time.time()
    train_pred_gaussian, acc_gaussian, acc_cv_gaussian = fit_ml_algo(GaussianNB(), 
                                                                          X_train, 
                                                                          y_train, 
                                                                               10)
    gaussian_time = (time.time() - start_time)
    print("Accuracy: %s" % acc_gaussian)
    print("Accuracy CV 10-Fold: %s" % acc_cv_gaussian)
    print("Running Time: %s" % datetime.timedelta(seconds=gaussian_time))

    # Linear SVC
    start_time = time.time()
    train_pred_svc, acc_linear_svc, acc_cv_linear_svc = fit_ml_algo(LinearSVC(),
                                                                    X_train, 
                                                                    y_train, 
                                                                    10)
    linear_svc_time = (time.time() - start_time)
    print("Accuracy: %s" % acc_linear_svc)
    print("Accuracy CV 10-Fold: %s" % acc_cv_linear_svc)
    print("Running Time: %s" % datetime.timedelta(seconds=linear_svc_time))

    # Stochastic Gradient Descent
    start_time = time.time()
    train_pred_sgd, acc_sgd, acc_cv_sgd = fit_ml_algo(SGDClassifier(), 
                                                      X_train, 
                                                      y_train,
                                                      10)
    sgd_time = (time.time() - start_time)
    print("Accuracy: %s" % acc_sgd)
    print("Accuracy CV 10-Fold: %s" % acc_cv_sgd)
    print("Running Time: %s" % datetime.timedelta(seconds=sgd_time))

    # Decision Tree Classifier
    start_time = time.time()
    train_pred_dt, acc_dt, acc_cv_dt = fit_ml_algo(DecisionTreeClassifier(), 
                                                                    X_train, 
                                                                    y_train,
                                                                    10)
    dt_time = (time.time() - start_time)
    print("Accuracy: %s" % acc_dt)
    print("Accuracy CV 10-Fold: %s" % acc_cv_dt)
    print("Running Time: %s" % datetime.timedelta(seconds=dt_time))

    # Gradient Boosting Trees
    start_time = time.time()
    train_pred_gbt, acc_gbt, acc_cv_gbt = fit_ml_algo(GradientBoostingClassifier(), 
                                                                           X_train, 
                                                                           y_train,
                                                                           10)
    gbt_time = (time.time() - start_time)
    print("Accuracy: %s" % acc_gbt)
    print("Accuracy CV 10-Fold: %s" % acc_cv_gbt)
    print("Running Time: %s" % datetime.timedelta(seconds=gbt_time))

    models = pd.DataFrame({
        'Model': ['KNN', 'Logistic Regression', 'Naive Bayes', 
                  'Stochastic Gradient Decent', 'Linear SVC', 
                  'Decision Tree', 'Gradient Boosting Trees',
                  'CatBoost'],
        'Score': [
            acc_knn, 
            acc_log,  
            acc_gaussian, 
            acc_sgd, 
            acc_linear_svc, 
            acc_dt,
            acc_gbt,
            acc_catboost
        ]})
    print("---Reuglar Accuracy Scores---")
    a1 = models.sort_values(by='Score', ascending=False)

    cv_models = pd.DataFrame({
        'Model': ['KNN', 'Logistic Regression', 'Naive Bayes', 
                  'Stochastic Gradient Decent', 'Linear SVC', 
                  'Decision Tree', 'Gradient Boosting Trees',
                  'CatBoost'],
        'Score': [
            acc_cv_knn, 
            acc_cv_log,      
            acc_cv_gaussian, 
            acc_cv_sgd, 
            acc_cv_linear_svc, 
            acc_cv_dt,
            acc_cv_gbt,
            acc_cv_catboost
        ]})
    print('---Cross-validation Accuracy Scores---')
    a2 = cv_models.sort_values(by='Score', ascending=False)
    
    return {'a1':a1, 'a2':a2}