import numpy as np
from sklearn.model_selection import cross_validate
from hyperopt import fmin, hp, tpe, Trials, STATUS_OK
from functools import partial
import lightgbm as lgbm

import seaborn as sns; sns.set(color_codes=True)

def format_float(a):
    """Function to check and convert float to int without data loss.
    
    Parameters
    ----------
    a : any
        Parameter for which conversion is attempted.

    Returns
    -------
    int : input converted to int from float without data loss else returns the input value.
    """
    if isinstance(a, float) and (a).is_integer():
            return int(a)
    else: return a
    
def objective(clf, space, presets, n_fold=3):
    """Objective function to be minimised for optimisation of bias variance tradeoff.
    
    Parameters
    ----------
    clf : partial function
        Partial function with moedl object.
    space : dict
        Minima (global/local) search space bounds.
    presets : dict
        Presets provided to partial function or clf object.
    n_fold : int, default=3
        Number of times k-fold cross validation to be applied. For larger data set use >3.

    Returns
    -------
    dict
        loss : objective function value
        status : run complete status.
        
    Notes
    -------
    Constants affecting behaviour of the optimisation function.
    
    delta : float,
        The difference beyond which exponential penalisation begins. The difference is between train and test gini.
        delta ∝ 1/penalisation
    std : float,
        The standard deviation in error difference for penalisation. std ∝ 1/penalisation
    """
    
    params = {k:format_float(v) for k, v in {**space,**presets}.items()}
    cv = cross_validate(clf.set_params(**params), X_train, y_train, cv=n_fold, scoring='roc_auc',
                        n_jobs=-1, error_score='raise',
                        return_train_score=True, return_estimator=False)
    
    train_gini = np.mean((2*cv['train_score'] - 1))
    test_gini = np.mean((2*cv['test_score'] - 1))
    
    x = np.abs(train_gini - test_gini)
    
    delta, std = 0.05, 0.0002
    f_val = np.piecewise(x, [x < delta, x >= delta], [test_gini, test_gini*(np.exp(-0.5*((x-delta)**2)/std))])
    return {'loss': -f_val, 'status': STATUS_OK}

def lgbm_partial():
    """Example for setting up partial objective function using binary log loss classification lgbm model.

    Returns
    -------
    dict
        loss : objective function value
        status : run complete status.
    """
    presets = {
        'class_weight': None,
        'objective': 'binary',
        'boosting': 'dart'
    }

    space = {
        'learning_rate': hp.loguniform('learning_rate', np.log(0.001), np.log(0.2)),
        'num_leaves': hp.quniform('num_leaves', 8, 128, 2),
#         'max_depth': hp.quniform('num_leaves', 8, 128, 2)
        'n_estimators': hp.quniform('n_estimators', 100, 300, 2),
        'max_depth': hp.quniform('max_depth', 3, 7, 1),
        'colsample_bytree': hp.uniform('colsample_bytree', 0.3, 1.0)
    }
    assert ~bool(set(presets.keys()) & set(space.keys()))
    fmin_objective = partial(objective, clf = lgbm.LGBMClassifier(), presets = presets)
    return fmin_objective

def hyper_trials(max_evals=32):
    """Run trials for optimisation. For spark use spark trials in the the function.
    
    Parameters
    ----------
    max_evals : int
        Maximum iterations for optimisation run.

    Returns
    -------
    dict
        optimal hyperparameters.
    """
    trials = Trials()
    h_star = fmin(fn = fmin_objective, algo = tpe.suggest, space = space, max_evals=max_evals, trials = trials)
    h_opt = {k:format_float(v) for k, v in h_star.items()}
    return h_opt, trials

def error_analysis(trials):
    """Plots epoch and error from hyperopt trials.
    
    Parameters
    ----------
    trials : hyperopt trial object
    """
    data = pd.DataFrame({'idx' : np.array(np.arange(len(trials.losses()))),'gini' : -np.array(trials.losses())})
    ax = sns.regplot(x="idx", y="gini", data=data)
    return None