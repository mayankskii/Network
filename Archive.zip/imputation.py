import numpy as np
import pandas as pd
from fancyimpute import KNN
from fancyimpute import IterativeImputer

class MeanImputation:
        """Implement mean imputation.

        Parameters
        ----------
        dataset: Dataframe
            The Pandas dataframe to be processed.

        Returns
        ----------
        Dataframe
            The converted dataframe which is suitable as model input.
        """
    @staticmethod
    def impute_data(data):
        df = pd.DataFrame(data)
        df = df.fillna(np.nanmean(data))
        return df[0].values.tolist()


class InterpolationImputation:
        """Implement Interpolation imputation.

        Parameters
        ----------
        dataset: Dataframe
            The Pandas dataframe to be processed.

        Returns
        ----------
        Dataframe
            The converted dataframe which is suitable as model input.
        """
    @staticmethod
    def impute_data(data):
        s = pd.Series(data)
        interpolation_result = s.interpolate(limit_direction='both').tolist()
        return interpolation_result


class KNNImputation:
        """Implement KNN imputation with 3 nearest neighbour.

        Parameters
        ----------
        dataset: Dataframe
            The Pandas dataframe to be processed.

        Returns
        ----------
        Dataframe
            The converted dataframe which is suitable as model input.
        """
    @staticmethod
    def impute_data(data):
        full_data = KNN(k=3).complete(data)
        return full_data


class KNNImputation_7:
    description = 'KNN_Imputation_N_7'

    @staticmethod
    def impute_data(data):
        """Implement KNN imputation with 7 nearest neighbour.

        Parameters
        ----------
        dataset: Dataframe
            The Pandas dataframe to be processed.

        Returns
        ----------
        Dataframe
            The converted dataframe which is suitable as model input.
        """
        full_data = KNN(k=7).complete(data)
        return full_data


class MICEImputation:
    mice_impute = IterativeImputer()
    traindatafill = Mice_impute.fit_transform(traindata)

    @staticmethod
    def impute_data(data):
        """Implement MICE imputation.

        Parameters
        ----------
        dataset: Dataframe
            The Pandas dataframe to be processed.

        Returns
        ----------
        Dataframe
            The converted dataframe which is suitable as model input.
        """
        mice_impute = IterativeImputer()
        full_data = mice_impute.fit_transform(data)
        return full_data
