#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer

def simpleimp(df,col,strategy):
    """Imputes the datframe using the method of mean, median or mode.
   
        Parameters
          -----------
            df:    pd.DataFrame
                   The dataframe which needs to be imputed.
            
            col1 : str
                   Target column for imputation.
            
            strategy : str
                       Strategy for imputation.

       Returns
          -----------
            pd.DataFrame
            The imputed dataframe.
    """

    if(strategy == 'mean'):
        fill_NaN=SimpleImputer(strategy='mean')
        df[col] = fill_NaN.fit_transform(df[col].values.reshape(-1,1))[:,0]
                
    elif(strategy == 'median'):
        fill_NaN=SimpleImputer(strategy='median')
        df[col] = fill_NaN.fit_transform(df[col].values.reshape(-1,1))[:,0]
                
    else:
        fill_NaN=SimpleImputer(strategy='most_frequent')
        df[col] = fill_NaN.fit_transform(df[col].values.reshape(-1,1))[:,0]
       
    return df


# In[5]:


import pandas as pd
path = 'C:\\Users\\hp\\EXL\\Accelerators\\'
df = pd.read_csv(path+'horse.csv',na_values='?')
df


# In[6]:


simpleimp(df,'abdomo_protein','mean')

