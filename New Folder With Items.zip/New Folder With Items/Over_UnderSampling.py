#!/usr/bin/env python
# coding: utf-8

# In[19]:


import pandas as pd
import numpy as np
from collections import Counter
from imblearn.over_sampling import RandomOverSampler

def oversampler(df,target):
    """Adding more examples from the minority class to help with data imbalance.
   
         Parameters
          -----------
            df:    pd.DataFrame
                   The dataframe which needs to be balanced.
            
            target : str
                   Target column.
    
        Returns
          -----------
            pd.DataFrame
            The balanced dataframe.
    
    """
    
    column_names = list(df.columns)    
    
    X = df.copy()
    y = df[target]
    ros = RandomOverSampler()
    ros.fit(X, y)
    X_resampled, y_resampled = ros.fit_resample(X, y)
    print('Resampled dataset shape %s' % Counter(y_resampled))
    return X_resampled
    


# In[20]:


import pandas as pd
import numpy as np
from collections import Counter
from imblearn.under_sampling import RandomUnderSampler

def undersampler(df,target):
    """Removing samples from the majority class to help with data imbalance.
   
         Parameters
          -----------
            df:    pd.DataFrame
                   The dataframe which needs to be balanced.
            
            target : str
                   Target column.
    
        Returns
          -----------
            pd.DataFrame
            The balanced dataframe.
    
    """
    
    column_names = list(df.columns)    
    
    X = df.copy()
    y = df[target]
    rus = RandomUnderSampler()
    rus.fit(X, y)
    X_resampled, y_resampled = rus.fit_resample(X, y)
    print('Resampled dataset shape %s' % Counter(y_resampled))
    return X_resampled
    


# In[23]:


import pandas as pd
path = 'C:\\Users\\hp\\EXL\\Accelerators\\'
df = pd.read_csv(path+'horse.csv',na_values='?')
df


# In[26]:


target_count = df.surgery.value_counts()
print('Class 0:', target_count['no'])
print('Class 1:', target_count['yes'])
print('Proportion:', round(target_count['no'] / target_count['yes'], 2), ': 1')

target_count.plot(kind='bar', title='Count (target)');


# In[22]:


undersampler(df,'surgery')


# In[18]:


oversampler(df,'surgery')

