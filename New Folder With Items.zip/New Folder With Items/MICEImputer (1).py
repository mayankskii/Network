#!/usr/bin/env python
# coding: utf-8

# In[11]:


import pandas as pd
import numpy as np
from fancyimpute import IterativeImputer
    


def miceimp(df,col1,col2,missing = np.nan):
    """Imputes the datframe using the method of Multiple Imputation by Chained Equations.
   
        Parameters
          -----------
            df:    pd.DataFrame
                   The dataframe which needs to be imputed.
            
            col1 : str
                   Target column for imputation.
            col2 : str
                   Column with which you need to impute with the help of.
            
    
        Returns
          -----------
            pd.DataFrame
            The imputed dataframe.
    """
    
    if missing != np.nan:
        df[col1].replace(to_replace = missing, value = np.nan, inplace = True)
    else: pass
    
    def encode(data):
        '''function to encode non-null data and replace it in the original data'''
        #retains only non-null values
        nonulls = np.array(data.dropna())
        #reshapes the data for encoding
        impute_reshape = nonulls.reshape(-1,1)
        #encode date
        impute_ordinal = encoder.fit_transform(impute_reshape)
        #Assign back encoded values to non-null values
        data.loc[data.notnull()] = np.squeeze(impute_ordinal)
        return data
    
    if str(df[col1].dtype) in ['object','category']:
        encoder = OrdinalEncoder()
        encode(df[col1])
    else: pass
    
    if str(df[col2].dtype) in ['object','category']:
        encoder = OrdinalEncoder()
        encode(df[col2])
    else: pass
        
    
    column_names = list(df.columns)
    new = pd.DataFrame(columns = [col2,col1])
    new = df[[col2,col1]]
    nex = df.drop([col2,col1], axis = 1)
    mice_imp = IterativeImputer()
    imputed = mice_imp.fit_transform(new)
    imputed_df = pd.DataFrame(imputed, columns = new.columns)
    final = pd.concat([imputed_df,nex], join = 'outer', axis = 1)
    final=final[column_names]
        
    return final


# In[18]:


miceimp(df,'abdomo_protein','surgery')


# In[17]:


import pandas as pd
path = 'C:\\Users\\hp\\EXL\\Accelerators\\'
df = pd.read_csv(path+'horse.csv',na_values='?')
df

