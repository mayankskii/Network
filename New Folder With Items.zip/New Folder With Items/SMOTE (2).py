#!/usr/bin/env python
# coding: utf-8

# In[26]:


import pandas as pd
import numpy as np
from sklearn import preprocessing, model_selection, metrics
from sklearn.model_selection import train_test_split, StratifiedKFold
from imblearn.over_sampling import SMOTENC


def smote_sampler(df,target):
    """Adds rows to the dataframe to help with data imbalance.
   
         Parameters
          -----------
            df:    pd.DataFrame
                   The dataframe which needs to be balanced.
            
            target : str
                   Target column.
    
        Returns
          -----------
            pd.DataFrame
            The balanced dataframe.
    
    """

    column_names = list(df.columns)    
    
    features = df.drop([target], axis=1)
    labels = df[target]    
    
    # Splitting categorical features
    df3=features.select_dtypes('object')
    cat_cols=df3.columns
    cat_features = features[cat_cols]
    features = features.drop(cat_cols, axis=1)
    
    # Use label encoding to convert categorical features to numeric
    le = preprocessing.LabelEncoder()
    cat_features = cat_features.apply(le.fit_transform)
    
    # Merge with numeric features
    features = features.merge(cat_features, left_index=True, right_index=True)

    # Split data into a training set and a test set
    X_train, X_test, y_train, y_test = train_test_split(features, labels,
    test_size=0.20, shuffle=True, random_state=42)

    # Scale X to be between 0 and 1 (can speed up processing and help with accuracy)
    scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.fit_transform(X_test)

    # Check that we have the same number of rows and columns in both the training and test set
    print(X_train.shape)
    print(X_test.shape)

    
    # Get column indices instead of names for categorical features (required input for SMOTE-NC)
    cat_cols_ind = []
    for key in cat_cols:
        ind = features.columns.get_loc(key)
        cat_cols_ind.append(ind)

    # Fit SMOTE-NC
    smote_nc = SMOTENC(categorical_features=cat_cols_ind, random_state=42,k_neighbors=2)
    features_resampled, labels_resampled = smote_nc.fit_resample(features, labels)
    
    # Split the resampled data into a training set and a test set
    X_train_re, X_test_re, y_train_re, y_test_re = train_test_split(features_resampled, labels_resampled,
                                                                    test_size=0.20, shuffle=True, random_state=42)

    # Scale X to be between 0 and 1 (can speed up processing and help with accuracy)
    scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))
    X_train_re = scaler.fit_transform(X_train_re)
    X_test_re = scaler.fit_transform(X_test_re)

    # Check that we have the same number of rows and columns in both the training and test set
    print(X_train_re.shape)
    print(X_test_re.shape)
    
    df_smote = pd.concat([pd.DataFrame(features_resampled), pd.DataFrame(labels_resampled)], axis=1)
    df_smote = df_smote[column_names]
    
    return df_smote


# In[50]:


import pandas as pd
path = 'C:\\Users\\hp\\EXL\\Accelerators\\'
df = pd.read_csv(path+'cred.csv')
df


# In[51]:


smote_sampler(df,'A1')

