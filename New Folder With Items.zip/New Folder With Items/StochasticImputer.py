#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
from sklearn.preprocessing import OrdinalEncoder
from autoimpute.imputations.series import StochasticImputer

def stoimp(df):
    """Imputes the datframe using the method of Stochastic Regression.
        Parameters
          -----------
            df:    pd.DataFrame
                   The dataframe which needs to be imputed.
            
            col1 : str
                   Target column for imputation.
           
    
        Returns
          -----------
            pd.DataFrame
            The imputed dataframe.
    
    """

    
    encoder = OrdinalEncoder()
    
    df2=df.copy()
       
    df1=df.select_dtypes('object')
    cat_cols=df1.columns
    cols = df2.columns.tolist()
    
    def encode(data):
        '''function to encode non-null data and replace it in the original data'''
        #retains only non-null values
        nonulls = np.array(data.dropna())
        #reshapes the data for encoding
        impute_reshape = nonulls.reshape(-1,1)
        #encode date
        impute_ordinal = encoder.fit_transform(impute_reshape)
        #Assign back encoded values to non-null values
        data.loc[data.notnull()] = np.squeeze(impute_ordinal)
        return data

    #create a for loop to iterate through each column in the data
    for columns in cat_cols:
        encode(df[columns])

    
    missing_columns = df.loc[:,df.isnull().any()].columns
       
    modf = df.dropna(axis=1,how='any')
    
    def random_imputation(df, feature):

        number_missing = df[feature].isnull().sum()
        observed_values = df.loc[df[feature].notnull(), feature]
        df.loc[df[feature].isnull(), feature + '_imp'] = np.random.choice(observed_values, number_missing, replace = True)

        return df

    for feature in missing_columns:
        df[feature + '_imp'] = df[feature]
        df = random_imputation(df, feature)      
       
    random_data = pd.DataFrame(columns = [name for name in missing_columns])

    for feature in missing_columns:
        random_data[feature] = df[feature + '_imp']
        parameters = list(set(df.columns) - set(missing_columns) - {feature + '_imp'})

        model = linear_model.LinearRegression()
        model.fit(X = df[parameters], y = df[feature + '_imp'])

        #Standard Error of the regression estimates is equal to std() of the errors of each estimates
        predict = model.predict(df[parameters])
        std_error = (predict[df[feature].notnull()] - df.loc[df[feature].notnull(), feature + '_imp']).std()

        #observe that I preserve the index of the missing data from the original dataframe
        random_predict = np.random.normal(size = df[feature].shape[0],loc = predict, scale = std_error)
        random_data.loc[(df[feature].isnull()) & (random_predict > 0), feature] = random_predict[(df[feature].isnull()) & (random_predict > 0)]

    final = pd.concat([modf,random_data], join = 'outer', axis = 1)
    
    final=final[cols]
        
    return final.head()


# In[ ]:


import pandas as pd
import numpy as np
from sklearn.preprocessing import OrdinalEncoder
from autoimpute.imputations.series import StochasticImputer

def stoimp(df):
    """Imputes the datframe using the method of Stochastic Regression.
        
        Parameters
          -----------
            df:    pd.DataFrame
                   The dataframe which needs to be imputed.
            
            col1 : str
                   Target column for imputation.
           
    
        Returns
          -----------
            pd.DataFrame
            The imputed dataframe.
    
    """

    column_names = list(df.columns)
    column_names.remove(col1)
    nex = pd.getdummies(df[column_names], drop_first = True)
    target = df[col1]
    nex = pd.concat([taregt, nex], axis = 1)
    train = nex[pd.isnull(nex[col1]) == False]
    pred = nex[pd.isnull(nex[col1]) == True]
    if len(pred) == 0:
        return
    
    y = train[col1]
    train.drop(col1, axis = 1, inplace =True)
    pred.drop(col1, axis = 1, inplace =True)
    Sto = StochasticImputer()
    Sto.fit(train,y)
    for x in list(pred.index):
        value = Sto.impute(pred.loc[[x]])
        df.loc[x,col1] = value[0]
        
    return df


# In[ ]:


import pandas as pd
path = 'C:\\Users\\hp\\EXL\\Accelerators\\'
df = pd.read_csv(path+'horse.csv',na_values='?')
df.head()


# In[ ]:


stoimp(df)

